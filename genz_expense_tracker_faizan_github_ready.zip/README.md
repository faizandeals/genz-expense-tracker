
# GenZ Expense Tracker

Simple Flutter expense tracker.

## Run

flutter pub get
flutter run

Footer branding: Made by Faizan
